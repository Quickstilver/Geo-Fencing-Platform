const Pool = require("pg").Pool;

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "postgres",
  password: "stefano",
  port: 5432
});

//CREATE USER NELLA TABELLA CAR
const createUser = (request, id, date) => {
  const query = {
    text:
      'INSERT INTO public."traiettoriespaz" ("id","geom", "date") VALUES ($3,ST_SetSRID(ST_MakePoint($2,$1 ), 4326),$4 )',
    values: [request[0], request[1], id, date]
  };
  pool.query(query, (error, results) => {
    if (error) {
      console.log(error.stack);
    } else {
      console.log("inserito");
    }
  });
};

//CREATE USER NELLA TABELLA BIKE
const createUserBike = (request, id, date) => {
  const query = {
    text:
      'INSERT INTO public."traiettorieBike"("id","geom", "date") VALUES ($3,ST_SetSRID(ST_MakePoint($2,$1 ), 4326),$4 )',
    values: [request[0], request[1], id, date]
  };
  pool.query(query, (error, results) => {
    if (error) {
      console.log(error.stack);
    } else {
      console.log("inserito utente bike");
    }
  });
};

//CREATE USER NELLA TABELLA CAR
const createUserCar = (request, id, date) => {
  const query = {
    text:
      'INSERT INTO public."traiettorieCar"("id","geom", "date") VALUES ($3,ST_SetSRID(ST_MakePoint($2,$1 ), 4326),$4 )',
    values: [request[0], request[1], id, date]
  };
  pool.query(query, (error, results) => {
    if (error) {
      console.log(error.stack);
    } else {
      console.log("inserito utente car");
    }
  });
};

// Create user nella tabella AVTIME
 //prima registrazione
const inserTime = (currDate,id) => {
  const query = {
    text:
      'INSERT INTO public."avetime"("d1","id") VALUES ($1, $2 )',
    values: [currDate, id]
  };
  pool.query(query, (error, results) => {
    if (error) {
      console.log(error.stack);
    } else {
      console.log("insertTime");
    }
  });
};



const updateTime = (id,notiTime) => {
  const query = {
    text:
     'UPDATE public."avetime" SET d2= $2 WHERE (d1= (SELECT MAX(d1) FROM avetime) AND id = $1 AND d2 is null)',
      //'UPDATE public."avetime" SET d2= $2 WHERE ID = $1 AND d1 < $2;', // 59f54416d6c583a2, 2020-03-23 15:37:02+01
    values: [id, notiTime]
  };
  pool.query(query, (error, results) => {
    if (error) {
      console.log(error.stack);
    } else {
      console.log("updateTime");
    }
  });
};




// var checkGeoFence = (request) =>  {
//  point = request[1]+" "+request[0];
//   pool.query("select message from geofence_walk where (ST_Within(ST_GeomFromText('POINT("+point+")', 4326), geom))",(err, res)  => {

//     if (err) {
//       console.log(err.stack)
//     } else {

//       if (res.rows != ""){
//        // console.log(res.rows[0].message)

//         link = res.rows[0].message;

//       }else{
//         console.log("fuori dal geoFence");
//       }
//     }

//   })
//   return ('ciao')
// }

//CONTROLLO UTENTE DENTRO GEOFENCE
async function checkGeoFence(request, tabella) {
  console.log("request", request)
  console.log("tab", tabella)
  point = request[1] + " " + request[0];
  let response;
  try {
    response = await pool.query(
      "select message from "+tabella+" where (ST_Within(ST_GeomFromText('POINT(" +
        point +
        ")', 4326), geom))"
    );
    // console.log(response.rows[0])

    if (response.rows.length > 0) {
      return response.rows[0].message;
    } else {
      return "fuori";
    }
  } catch (error) {
    console.log("fuori dal geoFence");
  }
  return response;
}

//SELECT GEO FENCE WALK
async function selectGeoFence() {
  let response;
  try {
    response = await pool.query(
      "select ST_asText(geom) from geofence_walk"
    );
    console.log(response.row.geo_json);

    if (response.rows.length > 0) {
      return response.rows[0];
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT TRAIETTORIE UTENTI WALK
async function selectTraiettorie() {
  let response;
  try {
    response = await pool.query(
      // "select  DISTINCT ON (id) id, ST_X(geom), ST_Y(geom) FROM  traiettoriespaz"
      //  "select  DISTINCT ON (id) id,  ST_AsText(geom)FROM  traiettoriespaz"
      "select DISTINCT ON (id) id, ST_AsText(ST_MakeLine(geom)) from traiettoriespaz group by  id"
    );
    //console.log(response.row.geo_json);
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT GEOFENCE BIKE
async function selectGeoFenceBike() {
  let response;
  try {
    response = await pool.query(
      "select ST_asText(geom) from geofence_bike"
    );
    console.log(response.row.geo_json);

    if (response.rows.length > 0) {
      return response.rows[0];
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT GEO FENCE CAR
async function selectGeoFenceCar() {
  let response;
  try {
    response = await pool.query(
      "select ST_asText(geom) from geofence_car"
    );
    console.log(response.row.geo_json);

    if (response.rows.length > 0) {
      return response.rows[0];
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//CONTA PUNTI ALL'INTERNO DI GEOFENCE WALK
async function contaPunti() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      "SELECT geofence_walk.id,ST_AsText(geofence_walk.geom), count(distinct(traiettoriespaz.id)) AS totale FROM geofence_walk LEFT JOIN traiettoriespaz ON st_contains(geofence_walk.geom, traiettoriespaz.geom) GROUP BY geofence_walk.id,geofence_walk.geom order by totale desc"
    );

    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//CONTA PUNTI ALL'INTERNO DI GEOFENCE BIKE
async function contaPuntiBike() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'SELECT geofence_bike.id,ST_AsText(geofence_bike.geom), count(distinct(public."traiettorieBike".id)) AS totale FROM geofence_bike LEFT JOIN public."traiettorieBike" ON st_contains(geofence_bike.geom, public."traiettorieBike".geom) GROUP BY geofence_bike.id,geofence_bike.geom order by totale desc'
    );

    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//CONTA PUNTI ALL'INTERNO DI GEOFENCE CAR
async function contaPuntiCar() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'SELECT geofence_car.id,ST_AsText(geofence_car.geom), count(distinct(public."traiettorieCar".id)) AS totale FROM geofence_car LEFT JOIN public."traiettorieCar" ON st_contains(geofence_car.geom, public."traiettorieCar".geom) GROUP BY geofence_car.id,geofence_car.geom order by totale desc'
    );

    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT PATH_CAR
async function getPathCar() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'select DISTINCT ON (id) id, ST_AsText(ST_MakeLine(geom)) from public."traiettorieCar" group by  id'
    );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT PATH_BIKE
async function getPathBike() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'select DISTINCT ON (id) id, ST_AsText(ST_MakeLine(geom)) from public."traiettorieBike" group by  id'
    );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//KMEAN WALK

async function getKmean() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      "SELECT ST_ClusterKMeans(geom, 3) OVER() AS cid, tt.id, ST_AsText(geom) " +
        "FROM traiettoriespaz tt  INNER JOIN (SELECT id, MAX(date) AS MaxDateTime FROM traiettoriespaz GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime"
    );

    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//KMEAN BIKE

async function getKmeanBike() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'SELECT ST_ClusterKMeans(geom, 3) OVER() AS cid, tt.id, ST_AsText(geom) FROM public."traiettorieBike" tt  INNER JOIN (SELECT id, MAX(date) AS MaxDateTime FROM public."traiettorieBike" GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime'
    );

    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//KMEAN CAR

async function getKmeanCar() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'SELECT ST_ClusterKMeans(geom, 3) OVER() AS cid, tt.id, ST_AsText(geom) FROM public."traiettorieCar" tt  INNER JOIN (SELECT id, MAX(date) AS MaxDateTime FROM public."traiettorieCar" GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime'
    );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SUGGERIMENTI GEOFENCE WALK

async function getGeoFenceAdvice() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      "Select ST_ClusterDBSCAN(geom, 0.005, 1) OVER() AS cid, id, ST_AsText(geom)" +
      "from(SELECT geom, tt.id, MaxDateTime FROM  traiettoriespaz tt  INNER JOIN (SELECT  id, MAX(date) AS MaxDateTime FROM traiettoriespaz GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime EXCEPT(SELECT tr.geom, tr.id, date FROM traiettoriespaz as tr join geofence_walk as geo on st_contains(geo.geom, tr.geom))) as finale"
   );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SUGGERIMENTI GEOFENCE CAR
async function getGeoFenceAdviceCar() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'Select ST_ClusterDBSCAN(geom, 0.005, 1) OVER() AS cid, id, ST_AsText(geom)' +
      'from(SELECT geom, tt.id, MaxDateTime FROM  "traiettorieCar" tt  INNER JOIN (SELECT  id, MAX(date) AS MaxDateTime FROM "traiettorieCar" GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime EXCEPT(SELECT tr.geom, tr.id, date FROM "traiettorieCar" as tr join geofence_car as geo on st_contains(geo.geom, tr.geom))) as finale'
   );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SUGGERIMENTI GEOFENCE BIKE
async function getGeoFenceAdviceBike() {
  let response;
  try {
    console.log("resQuery", response);
    response = await pool.query(
      'Select ST_ClusterDBSCAN(geom, 0.005, 1) OVER() AS cid, id, ST_AsText(geom)'+
      'from(SELECT geom, tt.id, MaxDateTime FROM  "traiettorieBike" tt  INNER JOIN (SELECT  id, MAX(date) AS MaxDateTime FROM "traiettorieBike" GROUP BY id) groupedtt ON tt.id = groupedtt.id AND tt.date = groupedtt.MaxDateTime EXCEPT(SELECT tr.geom, tr.id, date FROM "traiettorieBike" as tr join geofence_bike as geo on ST_Contains(geo.geom, tr.geom))) as finale'
    );
    if (response.rows.length > 0) {
      return response.rows;
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}

//SELECT AVERAGE TIME
async function selectAvtime() {
  let response;
  try {
    response = await pool.query(
      "SELECT EXTRACT( SECOND FROM somma/tot) as media from(    SELECT SUM(diff) as somma,count(diff) as tot from(	select id,(d2-d1) AS diff from avetime where d2 is not null) as foo) as finale"
    );
    
    if (response.rows.length > 0) {
      return response.rows[0];
    } else {
      return "OK";
    }
  } catch (error) {
    console.log("ERRORE");
  }
  return response;
}



module.exports = {
  createUser,
  createUserBike,
  createUserCar,
  inserTime,
  updateTime,
  checkGeoFence,
  selectGeoFence,
  selectTraiettorie,
  selectGeoFenceBike,
  selectGeoFenceCar,
  selectAvtime,
  contaPunti,
  contaPuntiBike,
  contaPuntiCar,
  getPathBike,
  getPathCar,
  getKmean,
  getKmeanCar,
  getKmeanBike,
  getGeoFenceAdvice,
  getGeoFenceAdviceCar,
  getGeoFenceAdviceBike
};
