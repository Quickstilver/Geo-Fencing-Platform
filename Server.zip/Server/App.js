var express = require("express");
var app = express();
const path = require("path");
const router = express.Router();
app.use("/static", express.static(__dirname + "/public"));

const db = require("./queries");

const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true
  })
);

app.get("/", function(req, res) {
  res.send("Hello World!");
});

//GET DATA FROM ANDROID
app.post("/postdata", async function(req, res) {
  var link = "";
  var vecchioLink = "";
  var data = req.body; // your data
  // do something with that data (write to a DB, for instance)
  console.log(data);

  // checkInsideGeoFence = false;
  // console.log("lat:", data.geometry.coordinates);
  // console.log("lon:", data.geometry.coordinates);
  // console.log("idDev:", data.id);
  // console.log("Current Date:", data.properties);
  // console.log("mob:", data.properties.TipoMob);
  

  var tipoMob = data.properties.TipoMob;
  currDate = new Date(data.properties.Date);
  notiTime = new Date(data.properties.notificationTime)
  console.log('Tempo di arrivo:', currDate)
  console.log('Tempo di notifica:', notiTime)
  var tabella;

  //inserisco le coord dell'utente del db
  coord = data;

  switch (tipoMob) {
    case "IN_VEHICLE":
      tabella = "geofence_car"
      await db.createUserCar(data.geometry.coordinates, data.id, currDate);

      break;
    case "ON_BICYCLE":
      await db.createUserBike(data.geometry.coordinates, data.id, currDate);
      tabella = "geofence_bike"
      break;
    default:
      await db.createUser(data.geometry.coordinates, data.id, currDate);
      tabella = "geofence_walk"
  }

  //controllo se l'utente si trova all'interno del geofence
  await db.checkGeoFence(data.geometry.coordinates, tabella).then(function(result) {
    //console.log('link',result) // "Some User token"
    link = result;
  });

  console.log("mess", link);
  if (link != vecchioLink) {
    vecchioLink = link;

    res.status(200).json({
      //message: "Data received successfully"
      message: link
    });
  }

 ////riempi tabella avetime
 
 if (notiTime == 'Invalid Date'){
   await db.inserTime(currDate,data.id);
  console.log("inseritoprimo");
  }
 else {
   try {
     await db.updateTime(data.id,notiTime);
     setTimeout( async function(){ await db.inserTime(currDate,data.id) ;}, 3000);
        
    } catch (error) {
      console.log(error);        
    }   

  }

    
});

app.get("/prova", function(req, res) {
  res.sendFile(path.join(__dirname + "/openLayer.html"));
});

//eseguo query  geo fence walk
app.post("/prova/getGeoFence", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.selectGeoFence().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("allGeofence", risultato);
  });
  res.json({
    output: risultato
  });
});

//eseguo query geo fence bike
app.post("/prova/getGeoFenceBike", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.selectGeoFenceBike().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("allGeofenceBike", risultato);
  });
  res.json({
    output: risultato
  });
});

// eseguo query geo fence car
app.post("/prova/getGeoFenceCar", async function(req, res) {
  var risultato;

  await db.selectGeoFenceCar().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("allGeofenceCar", risultato);
  });
  res.json({
    output: risultato
  });
});

//ottengo le posizioni degli utenti
app.post("/prova/getTraiettorieWalk", async function(req, res) {
  var risultato = [];
  await db.selectTraiettorie().then(function(result) {
    risultato.push(result);
    console.log("allTraiettorie", risultato);
  });
  res.json({
    output: risultato
  });
});

//eseguo query  conta punti
app.post("/prova/getPuntiWalk", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.contaPunti().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("punti dentro geo fence", risultato);
  });
  res.json({
    output: risultato
  });
});

//eseguo query  conta punti bike
app.post("/prova/getPuntiBike", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.contaPuntiBike().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("punti dentro geo fence bike", risultato);
  });
  res.json({
    output: risultato
  });
});

//eseguo query  conta punti car
app.post("/prova/getPuntiCar", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.contaPuntiCar().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("punti dentro geo fence car", risultato);
  });
  res.json({
    output: risultato
  });
});


//select path_walk
app.post("/prova/getPathWalk", async function(req, res) {
  var risultato = [];
  await db.getPathWalk().then(function(result) {
    risultato.push(result);
    console.log("allPathWalk", risultato);
  });
  res.json({
    output: risultato
  });
});

//select path_car
app.post("/prova/getPathCar", async function(req, res) {
  var risultato = [];
  await db.getPathCar().then(function(result) {
    risultato.push(result);
    console.log("allPathCar", risultato);
  });
  res.json({
    output: risultato
  });
});

//select path_bike
app.post("/prova/getPathBike", async function(req, res) {
  var risultato = [];
  await db.getPathBike().then(function(result) {
    risultato.push(result);
    console.log("allPathBike", risultato);
  });
  res.json({
    output: risultato
  });
});

//select kmean walk
app.post("/prova/getKmean", async function(req, res) {
  var risultato = [];
  await db.getKmean().then(function(result) {
    risultato.push(result);
    console.log("kmean", risultato);
  });
  res.json({
    output: risultato
  });
});

//select kmean bike
app.post("/prova/getKmeanBike", async function(req, res) {
  var risultato = [];
  await db.getKmeanBike().then(function(result) {
    risultato.push(result);
    console.log("kmeanBike", risultato);
  });
  res.json({
    output: risultato
  });
});

//select kmean car
app.post("/prova/getKmeanCar", async function(req, res) {
  var risultato = [];
  await db.getKmeanCar().then(function(result) {
    risultato.push(result);
    console.log("kmeanCar", risultato);
  });
  res.json({
    output: risultato
  });
});

//select suggerimenti geo fence walk
app.post("/prova/getGeofenceAdvice", async function(req, res) {
  var risultato = [];
  await db.getGeoFenceAdvice().then(function(result) {
    risultato.push(result);
    console.log("geoFenceAdvice", risultato);
  });
  res.json({
    output: risultato
  });
});

//select suggerimenti geo fence car
app.post("/prova/getGeofenceAdviceCar", async function(req, res) {
  var risultato = [];
  await db.getGeoFenceAdviceCar().then(function(result) {
    risultato.push(result);
    console.log("geoFenceAdviceCar", risultato);
  });
  res.json({
    output: risultato
  });
});

//select suggerimenti geo fence bike
app.post("/prova/getGeofenceAdviceBike", async function(req, res) {
  var risultato = [];
  await db.getGeoFenceAdviceBike().then(function(result) {
    risultato.push(result);
    console.log("geoFenceAdviceBike", risultato);
  });
  res.json({
    output: risultato
  });
});


// eseguo query tempo medio
app.post("/prova/getAvtime", async function(req, res) {
  // var test = req.body.test;
  var risultato;

  await db.selectAvtime().then(function(result) {
    //console.log('link',result) // "Some User token"
    risultato = result;
    console.log("tempoMedio", risultato);
  });
  
  res.json({
    
    output: risultato
  });
});





app.listen(3000, function() {
  console.log("Example app listening on port 3000!");
});

