
 //OpenLayer
 var osmLayerOL = new ol.layer.Tile({
    source: new ol.source.OSM({})
  });
  osmLayerOL.setVisible(true);


  var ztlLayer = new ol.layer.Vector({
    source: new ol.source.Vector({
      url:
        "./Users/Federica/Desktop/Server/support_files/geofence_walk.geojson",
      format: new ol.format.GeoJSON()
    }),
    style: myGJSONstyleZTL
  });

  var myGJSONstyleZTL = new ol.style.Style({
    image: new ol.style.Circle({
      radius: 5,
      fill: new ol.style.Fill({ color: "rgba(0, 255, 0, 0.13)" }),
      stroke: new ol.style.Stroke({ color: "green", width: 1 })
    })
  });

   //mappa

   var map = new ol.Map({
    target: "map",
    layers: [
      osmLayerOL,
      ztlLayer,
 
    ],
    view: new ol.View({
      center: ol.proj.fromLonLat([11.3394883, 44.4938134]),
      zoom: 13
    })
  });

  ztlLayer.setVisible(false);


  function setMapType(value) {
    console.log(value);

    if (value == "osm") {
      //map.addLayer(osmLayerOL );
      osmLayerOL.setVisible(true);
      osmLayerStam.setVisible(true);
    } else {
      console.log(value);
      osmLayerOL.setVisible(false);
      osmLayerStam.setVisible(true);
      //map.addLayer(osmLayerStam );
    }
  }

  function setZTLData() {
    ztlLayer.setVisible(false);
    var ztlButton = document.getElementsByName("ztl");
    if (ztlButton[0].checked == true) {
      console.log("checked");
      ztlLayer.setVisible(true);
    } else if (ztlButton[0].checked == false) {
      ztlLayer.setVisible(false);
    }
  }